<?php include 'header.php'; ?>
<?php include 'sub-menu.php'; ?>

    <div class="modal  fade m-auto" id="login" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
    <div class="modal-content">
    <form class="form-login login-form">
    <div class="box-content-login bg-white ">
    <div class="row">
    <div class="col-md-6">
      <h5>Sign in to continue</h5>
    </div>
    </div>
    <form class="login-form">
      <p class=" login-form-p">
     <input name="_username" class="text-input" placeholder="Email or Username" type="text"/>
    </p>
    <p class=" login-form-p">
          <input name="_password" class="text-input" placeholder="Password" type="password"/>
    </p>

            <p class=" login-form-p">
            <input class="login-check" id="remember" name="_remember" type="checkbox"/>
            <label>Keep me logged in</label>
            </p>
           <p class=" login-form-p">
          <button type="submit" class=" button text-input text-white"><span>Login now</span></button>
            </p>
          <div class="link m-auto text-center">
                    <span>
          <a href="#">Forgot Your Password</a>
                  </span>
    </div>
            <p class="login-form-p">Or Sign In With</p>
            <div class="row ml-5 mr-5 mt-4">
            <div class="col-md-4">
            <div class="link-social-google p-3 text-white text-center">
                  <a href="https://www.awwwards.com/about-evaluation/"><i class=" mr-1 fab fa-google-plus-g"></i>
                  <span>Google</span>
                  </a>
            </div>
            </div>
            <div class="col-md-4">
            <div class="link-social-twitter p-3 text-white text-center">
                  <a href="https://api.twitter.com/oauth/authenticate?oauth_token=JtdjMAAAAAAAyPCzAAABZ-Z5_sk"><i class=" mr-1 fab fa-twitter"></i>
                  <span>Twitter</span>
                  </a>
            </div>
            </div>
            <div class="col-md-4">
            <div class="link-social-face p-3 text-white text-center">
                  <a href="https://www.awwwards.com"><i class=" mr-1 fab fa-facebook-f"></i>
                  <span>FaceBook</span>
                  </a>
            </div>
            </div>
            </div>
            </form>
            </div>
            </form>
            </div>
            </div>
            </div>
                  <!-- login Form  -->

            <!-- Register Form  -->


        <div class="modal fade bd-example-modal-lg"  id="register" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
        <div class="modal-content">
        <form class="register-form">
        <div class="box-content-login bg-white ">
        <div class="row ml-3 mr-3">
        <div class="col-md-6">
            <h5>Register with</h5>
        </div>
        </div>
        <div class="row ml-5 mr-5 mt-4 mb-4">
        <div class="col-md-4">
        <div class="link-social-google p-3 text-white text-center">
                  <a href="https://www.awwwards.com/about-evaluation/"><i class=" mr-1 fab fa-google-plus-g"></i>
                  <span>Google</span>
                  </a>
        </div>
        </div>
        <div class="col-md-4">
        <div class="link-social-twitter p-3 text-white text-center">
                  <a href="https://api.twitter.com/oauth/authenticate?oauth_token=JtdjMAAAAAAAyPCzAAABZ-Z5_sk"><i class=" mr-1 fab fa-twitter"></i>
                  <span>Twitter</span>
                  </a>
        </div>
        </div>
        <div class="col-md-4">
        <div class="link-social-face p-3 text-white text-center">
                  <a href="https://www.awwwards.com"><i class=" mr-1 fab fa-facebook-f"></i>
                  <span>FaceBook</span>
                  </a>
        </div>
        </div>
        </div>
                         <p class="login-form-p"> Or with your E-mail</p>


                        <p class=" login-form-p">
          <input name="_username" class="text-input" placeholder="Username" type="text"/>
                        </p>
                        <p class=" login-form-p">
          <input name="_Umail" class="text-input" placeholder="E-mail" type="email"/>
                        </p>
                        <p class=" login-form-p">
          <input name="_password" class="text-input" placeholder="Password" type="password"/>
                        </p>
                        <p class=" login-form-p">
          <input name="_re password" class="text-input" placeholder=" Repeat Password" type="password"/>
                        </p>
                        <p class=" login-form-p">
            <input class="login-check" id="remember" name="_remember" type="checkbox"/>
                <label> I accept the <a href="#">Terms and Conditions</a> and <a href="#">Privacy Policy</a></label>
                        </p>
                        <p class=" login-form-p">
          <button type="submit" class=" button text-input text-white"><span>Create your Account</span></button>
                        </p>
        </div>
        </form>
        </div>
        </div>
        </div>
                  <!-- Register Form  -->


    <!-- H E A D E R  -->





<!-- About Menu -->
       <!-- Login Form  -->
      <!-- Button trigger modal -->

<div class="modal form-login fade m-auto" id="login" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
         <form>
  <div class="box-content-login bg-white ">
    <div class="row">
          <div class="col-md-6">
      <h5>Sign in to continue</h5>
               </div>
        <div class="col-md-6">
              <p>Not a member yet? <a class="text-info font-weight-bold" href="#" data-toggle="modal" data-target="#register" href="#!" class="btn main-menu-btn"> Register now</a> </p>
            </div>
            </div>
      <form class="login-form">
      <p class=" login-form-p">
     <input name="_username" class="text-input" placeholder="Email or Username" type="text"/>
    </p>
    <p class=" login-form-p">
          <input name="_password" class="text-input" placeholder="Password" type="password"/>
 </p>

            <p class=" login-form-p">
            <input class="login-check" id="remember" name="_remember" type="checkbox"/>
                <label>Keep me logged in</label>

 </p>
           <p class=" login-form-p">
          <button type="submit" class=" button text-input text-white"><span>Login now</span></button>
 </p>
          <div class="link m-auto text-center">

              <span>
          <a href="#">Forgot Your Password</a>
                  </span>
          </div>
   <p class="login-form-p">
       Or Sign In With
    </p>
          <div class="row ml-5 mr-5 mt-4">
                    <div class="col-md-4">
              <div class="link-social-google p-2 text-white text-center">
                  <a href="https://www.awwwards.com/about-evaluation/"><i class=" mr-1 fab fa-google-plus-g"></i>
                  <span>Google</span>
                  </a>
                  </div>
              </div>
                    <div class="col-md-4">
              <div class="link-social-twitter p-2 text-white text-center">
                  <a href="https://api.twitter.com/oauth/authenticate?oauth_token=JtdjMAAAAAAAyPCzAAABZ-Z5_sk"><i class=" mr-1 fab fa-twitter"></i>
                  <span>Twitter</span>
                  </a>
                  </div>
              </div>
              <div class="col-md-4">
              <div class="link-social-face p-2 text-white text-center">
                  <a href="https://www.awwwards.com"><i class=" mr-1 fab fa-facebook-f"></i>
                  <span>FaceBook</span>
                  </a>
                  </div>
              </div>
</div>
 </form>
</div>
</form>
    </div>
  </div>
</div>


<!-- Modal -->



                <!-- Login Form  -->
                      <!-- Register Form  -->



<div class="modal register-form fade m-auto" id="register" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      <form>
      <div class="box-content-login  bg-white ">
    <div class="row ml-3 mr-3">
          <div class="col-md-6">
      <h5>Register with</h5>
               </div>
        <div class="col-md-6">
              <p>Are you member?<a class="text-info font-weight-bold s" href="#" data-toggle="modal" data-target="#login" href="#!" class="btn main-menu-btn" > Login now</a> </p>
            </div>
            </div>
           <div class="row ml-5 mr-5 mt-4 mb-4">
                    <div class="col-md-4">
              <div class="link-social-google p-2 text-white text-center">
                  <a href="https://www.awwwards.com/about-evaluation/"><i class=" mr-1 fab fa-google-plus-g"></i>
                  <span>Google</span>
                  </a>
                  </div>
              </div>
                    <div class="col-md-4">
              <div class="link-social-twitter p-2 text-white text-center">
                  <a href="https://api.twitter.com/oauth/authenticate?oauth_token=JtdjMAAAAAAAyPCzAAABZ-Z5_sk"><i class=" mr-1 fab fa-twitter"></i>
                  <span>Twitter</span>
                  </a>
                  </div>
              </div>
              <div class="col-md-4">
              <div class="link-social-face p-2 text-white text-center">
                  <a href="https://www.awwwards.com"><i class=" mr-1 fab fa-facebook-f"></i>
                  <span>FaceBook</span>
                  </a>
                  </div>
              </div>
          </div>
                         <p class="login-form-p"> Or with your E-mail</p>


           <p class=" login-form-p">
          <input name="_username" class="text-input" placeholder="Username" type="text"/>
 </p>
           <p class=" login-form-p">
          <input name="_Umail" class="text-input" placeholder="E-mail" type="email"/>
 </p>
           <p class=" login-form-p">
          <input name="_password" class="text-input" placeholder="Password" type="password"/>
 </p>
           <p class=" login-form-p">
          <input name="_re password" class="text-input" placeholder=" Repeat Password" type="password"/>
 </p>
                     <p class=" login-form-p">
            <input class="login-check" id="remember" name="_remember" type="checkbox"/>
                <label> I accept the <a href="#">Terms and Conditions</a> and <a href="#">Privacy Policy</a></label>

 </p>
        <p class=" login-form-p">
          <button type="submit" class=" button text-input text-white"><span>Create your Account</span></button>
 </p>
      </div>
      </form>


    </div>
  </div>
</div>




                            <!-- Register Form  -->




    <!-- H E A D E R  -->


          <!-- EVALUATION SYSTEM  -->

        <!--transparent Section -->
        <div class="container fooled pb-5">
        <div class="row">
        <div class="col-md-9 py-4">
                  <h2 class="pt-5 mb-3"></h2>
                  <h1 class="font-weight-bold pt-2">A transparent and rigorous evaluation system implemented by experienced, world-renowned professionals.</h1>
                  <p class="py-3">Evaluating the talent and effort of the best web designers and developers is a hugely challenging job which requires the considerable knowledge and experience possessed by the Awwwards Jury.</p>
        </div>
        </div>
        </div>
      <!--transparent Section -->
              <!--Img - Section  -->
              <div class="container-fluid p-0 m-0">
          <img class="img-fluid" src="img/header.jpg"/>
              </div>
              <!--Img - Section -->

      <!--Criteria Section -->
      <div class="container bg-white mt-5 pb-5 mb-5">
      <div class="box-content">
          <h3>Criteria</h3>
          <p>Fairness is key when evaluating each website submitted to Awwwards, so we’ve created an evaluation system based on 4 criteria:
              <span>Design, Usability, Creativity and Content.</span>
          </p>
      <div class="row ml-3 mr-3">
      <div class="col-md-3 box-item">
      <div class="info">
      <div class="item bg-light text-center">
          <i class="text-danger fas fa-circle"></i>
      <div class="percentage">
            <h1>40</h1>
            <p>POINTS</p>
      </div>
      </div>
      </div>
      </div>
      <div class="col-md-3 box-item">
      <div class="info">
      <div class="item bg-light text-center">
          <i class="text-warning fas fa-circle"></i>
      <div class="percentage">
              <h1>30</h1>
              <p>POINTS</p>
      </div>
      </div>
      </div>
      </div>
      <div class="col-md-3 box-item">
      <div class="info">
      <div class="item bg-light text-center">
            <i class="text-info fas fa-circle"></i>
      <div class="percentage">
              <h1>20</h1>
              <p>POINTS</p>
      </div>
      </div>
      </div>
      </div>
      <div class="col-md-3 box-item">
      <div class="info">
      <div class="iteem bg-light text-center">
            <i class="text-primary fas fa-circle"></i>
      <div class="percentage">
              <h1>10</h1>
              <p>POINTS</p>
      </div>
      </div>
      </div>
      </div>
      </div>
      </div>
      <div class="clearfix"></div>
      </div>
            <!--Criteria Section -->
      <!--Voting System Section -->



      <div class="container bg-white mb-5">
      <div class="box-content">
          <h3>Voting System</h3>
      </div>
          <p>The process of evaluating the talent and effort of the best web designers and developers is a tremendously difficult job which requires the knowledge and experience of the Jury as well as the Awwwards users.</p>
          <p>Once approved, sites will be sent to a minimum of 14 Jury members, the two Jury scores furthest from the average will be automatically eliminated by our system. The voting process usually takes 5 days but if a site receives a high score from the Jury and at least 10 PRO & CHIEF users it can be awarded a SOTD before the end of the 5-day period. Jury votes are only revealed to SOTD winners.</p>

      <div class="row Users ml-2 mr-2">
      <div class="col-2">
      <div class="box-item">
          <img class="img-fluid" src="img/jury1.jpg"/>
      <div class="rate">7.5</div>
      </div>
      </div>
      <div class="col-2">
      <div class="box-item">
          <img class="img-fluid" src="img/jury2.jpg"/>
      <div class="rate">7.7</div>
      </div>
      </div>
      <div class="col-2">
      <div class="box-item">
          <img class="img-fluid" src="img/jury3.jpg"/>
      <div class="rate">8.1</div>
      </div>
      </div>
      <div class="col-2">
      <div class="box-item">
          <img class="img-fluid" src="img/jury4.jpg"/>
      <div class="rate">6.9</div>
      </div>
      </div>
      <div class="col-2">
      <div class="box-item">
          <img class="img-fluid" src="img/jury5.jpg"/>
      <div class="rate">7.5</div>
      </div>
      </div>
      <div class="col-2">
      <div class="box-item">
          <img class="img-fluid" src="img/jury6.jpg"/>
      <div class="rate">7.4</div>
      </div>
      </div>
      <div class="col-2">
      <div class="box-item">
          <img class="img-fluid" src="img/jury7.jpg"/>
      <div class="rate">7.0</div>
      </div>
      </div>
      <div class="col-2">
      <div class="box-item">
          <img class="img-fluid" src="img/jury8.jpg"/>
      <div class="rate">6.7</div>
      </div>
      </div>
      <div class="col-2">
      <div class="box-item">
          <img class="img-fluid" src="img/jury9.jpg"/>
      <div class="rate">7.5</div>
      </div>
      </div>
      <div class="col-2">
      <div class="box-item">
          <img class="img-fluid" src="img/jury10.jpg"/>
      <div class="rate">7.4</div>
      </div>
      </div>
      <div class="col-2">
      <div class="box-item">
          <img class="img-fluid" src="img/jury11.jpg"/>
      <div class="rate">8.0</div>
      </div>
      </div>
      <div class="col-2">
      <div class="box-item">
          <img class="img-fluid" src="img/jury12.jpg"/>
      <div class="rate">7.7</div>
      </div>
      </div>
      <div class="col-2">
      <div class="box-item">
          <img class="img-fluid" src="img/jury13.jpg"/>
      <div class="rate">7.3</div>
      </div>
      </div>
      <div class="col-2">
      <div class="box-item">
          <img class="img-fluid" src="img/jury14.jpg"/>
      <div class="rate">7.9</div>
      </div>
      </div>
      <div class="col-2">
      <div class="box-item">
          <img class="img-fluid" src="img/jury15.jpg"/>
      <div class="rate">9.3</div>
      </div>
      </div>
      <div class="col-2">
      <div class="box-item">
          <img class="img-fluid" src="img/jury16.jpg"/>
      <div class="rate">6.8</div>
      </div>
      </div>
      <div class="col-2">
      <div class="box-item">
          <img class="img-fluid" src="img/jury-all.jpg"/>
      <div class="rate">7.7</div>
      </div>
      </div>
              <p>
              <span>Users vote </span>
              <br>
              When calculating the <span>Users</span> vote, only votes made by users with <span>Professional</span> accounts, or <span>Chief</span> Users, who have passed through our validation system, will be taken into account. This rule is to avoid the creation of false accounts, set up solely for the purpose of benefiting or causing harm to particular nominees. If you suspect the creation of false users, please do <a class="text-info" href="#">report them here.</a>

              </p>
      </div>
      <div class="clearfix"></div>
      </div>
            <!--Voting System Section -->
      <!--Submission Process Section -->

      <div class="container bg-white mb-5 ">
      <div class="box-content">
          <h3>Submission Process</h3>
      </div>
      <p>When you submit a website to Awwwards, it must first be approved by our team who check that it meets the minimum requirements in order to then be sent to the Jury. It’s quite normal for sites to take up to a week to get published. Our approval process is carried out manually and can experience backlogs due to weekends and/or large volumes of submissions.</p>

            <!--Submission Process Section img -->
      <div class="row ml-3 mr-3">
      <div class="col-md-6 mb-4">
      <div class="section-img bg-light h-100">
              <h5>1. Submit Your Site</h5>
              <p>You have created a fantastic project and you want to share it with the world to get the recognition it deserves, time to send it to Awwwards!</p>
              <img class="img-fluid" src="img/submission.jpg"/>
      </div>
      </div>
      <div class="col-md-6 mb-4 mt-5">
      <div class="section-img h-100 bg-light">
              <h5>2. Voting</h5>
              <p>Once your site has been approved by Awwwards it is sent to our Jury and can be voted for by all the Awwwards users. This process lasts 5 days.</p>
              <img class="img-fluid" src="img/users.png"/>
      </div>
      </div>
      <div class="col-md-6 mb-4">
      <div class="section-img h-100 bg-light">
              <h5>3. Mobile Excellence</h5>
              <p>An expert will evaluate each site manually following this <a class="text-info" href="#"> Mobile Guidelines</a> based on Google criteria for mobile websites.
Those sites that reach a score of 70/100 or higher will be chosen for getting the Mobile Excellence badge. To become Mobile Site of the Week the site must be one of the highest voted in the last 3 months and also have won an Honorable Mention. It is then highlighted on the Awwwards homepage.</p>
              <div class="box-certificate">
              <img class="img-fluid" src="img/new-certificate-mobile.jpg"/>
              </div>
              </div>
              </div>
              <div class="col-md-6 mb-4 move">
              <div class="section-img h-100 bg-light ">
              <h5>4. Honorable Mention </h5>
              <p>
If the votes from CHIEF, PRO & Jury users are 6.5 or more, your site will receive an Honorable Mention</p>
              <div class="box-certificate ">
              <img class="img-fluid" src="img/new-certificate-hm.jpg"/>
              </div>
              </div>
              </div>
              <div class="col-md-6 mb-4">
              <div class="section-img h-100 bg-light ">
              <h5>5. Site of the Day </h5>
              <p>The sites with the highest marks will be awarded SOTD.</p>
              <div class="box-certificate ">
              <img class="img-fluid" src="img/new-certificate-sotd.jpg"/>
              </div>
              </div>
              </div>
              <div class="col-md-6 mb-4 move">
              <div class="section-img h-100 bg-light ">
              <h5>6. Developer Award</h5>
              <p>Once awarded a SOTD, the site is sent to the Developer Jury who evaluate it according to the following <a class="text-info" href="#">Guidelines</a> . Sites awarded higher than a 7 from the Developer Jury will be given a Developer Award.</p>
              <div class="box-certificate ">
              <img class="img-fluid" src="img/new-certificate-dev.jpg"/>
              </div>
              </div>
              </div>
              <div class="col-md-6 mb-4">
              <div class="section-img h-100 bg-light ">
              <h5>7. Site of the Month </h5>
              <p>The <span> eight highest-scoring sites</span> each month are nominated for Site of the Month and reviewed by the Jury a second time.<span>The Awwwards users play an important part in deciding the winner</span> ; the site which receives the most user votes will carry extra weight in the Jury’s final decision.</p>
              <div class="box-certificate ">
              <img class="img-fluid" src="img/new-certificate-sotm.jpg"/>
              </div>
              </div>
              </div>
              <div class="col-md-6 mb-4 move">
              <div class="section-img h-100 bg-light ">
              <h5>8. Site of the Year </h5>
              <p>All Site of the Month winners are automatically nominated for SOTY along with Awwwards own favorites .</p>
              <div class="box-certificate ">
              <img class="img-fluid" src="img/new-certificate-soty.jpg"/>
              </div>
              </div>
              </div>
              </div>
              </div>
      <!--Submission Process Section -->
          <!-- EVALUATION SYSTEM  -->


    <?php include 'footer.php'; ?>
