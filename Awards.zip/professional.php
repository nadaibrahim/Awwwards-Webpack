<?php include 'header.php'; ?>

    <!-- P R O F I S S I O N A L  M E N U -->

    <div class="main-menu bg-light border-bottom  ">
        <div class="row no-gutters ">
            <div class="col-md-6 ">
                <nav class="navbar navbar-expand-lg navbar-light  ">

                    <!--
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon"></span>
                </button>
-->

                    <div class="collapse navbar-collapse  navbae-winner">
                        <ul class="navbar-nav mr-auto">
                            <li class="nav-item active ">
                                <i class="nav-link about-menu">icon <span class="sr-only">(current)</span></i>
                            </li>

                            <li class="nav-item item dropdown">
                                <a class="nav-link about-menu " href="#"> DIRECTORY</a>
                            </li>
                            <li class="nav-item item dropdown">
                                <a class="nav-link about-menu" href="#">COUNTRIES</a>
                            </li>
                            <li class="nav-item item dropdown">
                                <a class="nav-link about-menu " href="#">CATEGORIES</a>
                            </li>
                            <li class="nav-item item dropdown">
                                <a class="nav-link about-menu " href="#">QUOTES</a>
                            </li>
                            <li class="nav-item item dropdown">
                                <a class="nav-link about-menu " href="#">TYPES</a>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
    </div>

    <!-- P R O F I S S I O N A L  M E N U -->

    <!--P R O F I S S I O N A L - B O D Y-->
 <div class="box-heading">
            <div class="box-left">
                <strong>Connecting with the digital world. <a href="#">Join the club!</a></strong>
            </div>
            <div class="box-right">
                <span class="total_users">2,812</span> professionals waiting. <strong class="js-toggle cursor-pointer" data-id="toggle-heading">More info</strong>
            </div>
        </div>
    <div class="container outer ">

        <div class="row">

            <!--        11-->
            <div class="col-md-3 ">
                <div class="items">
                    <div class="member">
                     <a href="#">   <img src="images/5c1b740a834e9.jpg" class=" sora" /></a>
                        <div class="caption row ">
                         <a href="#">   <img src="images/5a82baaab0802.png" />
                            </a>
                        </div>
                    </div>
                    <div class="content">
                                    <h3 class="row"><a href="#">AQuest</a></h3>
                                    <div class="row"><a href="#" class="url">aquest.it</a></div>
                                    <div class="row"> <span>Italy</span></div>
                                </div>
                    <div class="footer">


                     <div class="list-number-awards items-4">

            <div>
           <div class="box-item">
            <span>SOTD</span>
             <strong>33</strong>
                </div>

                 </div>
                <div>
        <div class="box-item">
             <span>SOTM</span>
            <strong>02</strong>
                     </div>

                     </div>
                    <div>
                    <div class="box-item">
                    <span>SOTY</span>
                    <strong>01</strong>
                         </div>

                                        </div>
                    <div>


        <div class="box-item box-usertype js-usertype style-dark" data-type="user_type_pro ">
            <span class="text-uppercase ">Int </span>
            <br>
                       <i class="fas fa-fingerprint"></i>

        </div>

    </div>

                                        </div>
                                </div>

                    </div>
                </div>

            <!--      22-->
                  <div class="col-md-3 ">
                <div class="items">
                    <div class="member">
                     <a href="#">   <img src="images/5c1b740a834e9.jpg" class=" sora" /></a>
                        <div class="caption row ">
                         <a href="#">   <img src="images/5a82baaab0802.png" />
                            </a>
                        </div>
                    </div>
                    <div class="content">
                                    <h3 class="row"><a href="#">AQuest</a></h3>
                                    <div class="row"><a href="#" class="url">aquest.it</a></div>
                                    <div class="row"> <span>Italy</span></div>
                                </div>
                    <div class="footer">


                     <div class="list-number-awards items-4">

            <div>
           <div class="box-item">
            <span>SOTD</span>
             <strong>33</strong>
                </div>

                 </div>
                <div>
        <div class="box-item">
             <span>SOTM</span>
            <strong>02</strong>
                     </div>

                     </div>
                    <div>
                    <div class="box-item">
                    <span>SOTY</span>
                    <strong>01</strong>
                         </div>

                                        </div>
                    <div>


        <div class="box-item box-usertype js-usertype style-dark" data-type="user_type_pro ">
            <span class="text-uppercase ">Int </span>
            <br>
                       <i class="fas fa-fingerprint"></i>

        </div>

    </div>

                                        </div>
                                </div>

                    </div>
                </div>

            <!--            33-->
                 <div class="col-md-3 ">
                <div class="items">
                    <div class="member">
                     <a href="#">   <img src="images/5c1b740a834e9.jpg" class=" sora" /></a>
                        <div class="caption row ">
                         <a href="#">  <img src="images/5a82baaab0802.png" />
                            </a>
                        </div>
                    </div>
                    <div class="content">
                                    <h3 class="row"><a href="#">AQuest</a></h3>
                                    <div class="row"><a href="#" class="url">aquest.it</a></div>
                                    <div class="row"> <span>Italy</span></div>
                                </div>
                    <div class="footer">


                     <div class="list-number-awards items-4">

            <div>
           <div class="box-item">
            <span>SOTD</span>
             <strong>33</strong>
                </div>

                 </div>
                <div>
        <div class="box-item">
             <span>SOTM</span>
            <strong>02</strong>
                     </div>

                     </div>
                    <div>
                    <div class="box-item">
                    <span>SOTY</span>
                    <strong>01</strong>
                         </div>

                                        </div>
                    <div>


        <div class="box-item box-usertype js-usertype style-dark" data-type="user_type_pro ">
            <span class="text-uppercase ">Int </span>
            <br>
                       <i class="fas fa-fingerprint"></i>

        </div>

    </div>

                                        </div>
                                </div>

                    </div>
                </div>
<!--44-->

                  <div class="col-md-3 ">
                <div class="items">
                    <div class="member">
                     <a href="#">   <img src="images/5c1b740a834e9.jpg" class=" sora" /></a>
                        <div class="caption row ">
                         <a href="#">   <img src="images/.jpeg" /><img src="images/5a82baaab0802.png" />
                            </a>
                        </div>
                    </div>
                    <div class="content">
                                    <h3 class="row"><a href="#">AQuest</a></h3>
                                    <div class="row"><a href="#" class="url">aquest.it</a></div>
                                    <div class="row"> <span>Italy</span></div>
                                </div>
                    <div class="footer">


                     <div class="list-number-awards items-4">

            <div>
           <div class="box-item">
            <span>SOTD</span>
             <strong>33</strong>
                </div>

                 </div>
                <div>
        <div class="box-item">
             <span>SOTM</span>
            <strong>02</strong>
                     </div>

                     </div>
                    <div>
                    <div class="box-item">
                    <span>SOTY</span>
                    <strong>01</strong>
                         </div>

                                        </div>
                    <div>


        <div class="box-item box-usertype js-usertype style-dark" data-type="user_type_pro ">
            <span class="text-uppercase ">Int </span>
            <br>
                       <i class="fas fa-fingerprint"></i>

        </div>

    </div>

                                        </div>
                                </div>

                    </div>
                </div>
        </div>
    </div>




    <div class="paginate">
                        <div class="cols-4"><span class="current item">1</span><a class="item" href="/websites/?page=2">2</a><a class="item" href="/websites/?page=3">3</a></div>
                        <div class="cols-4"><a class="item1 more" href="/websites/?page=2">SHOW ME MORE</a></div>
                    </div>

    <!--P R O F I S S I O N A L - B O D Y-->
<?php include 'footer.php'; ?>
